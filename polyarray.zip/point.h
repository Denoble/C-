/* Definition of Class Point inherited from abstract base class Shape */

#ifndef _point
#define _point
#include "shape.h"
class Point : public Shape {
public:
virtual void read();
virtual float area() const;
virtual float distance(const Point &p2) const;
virtual void I_am() const;
private:
float x;
float y;
};
#endif
