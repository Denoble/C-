/*Definition of Class Triangle inherited  from class Shape */

#ifndef _triangle
#define _triangle
#include "shape.h"
#include "point.h"

class Triangle : public Shape {
	private:
		Point P1;
Point P2;
		Point P3;
	public:
		virtual void read();
		virtual float area() const;
		virtual void I_am() const;
};
#endif
