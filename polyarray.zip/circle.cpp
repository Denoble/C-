/* The implementation of class Circle */

#include <iostream>
#include <math.h>
#include "circle.h"
using namespace std;

void Circle::read() {
	cout << "\nEnter radius of circle: ";
	cin >> radius;
	cout << "Enter center point of circle:";
	Point::read();
}
float Circle::area() const {
	const float pi = 3.14159f;
	return  pi * radius * radius;
}
void Circle::I_am() const {
	cout << "\nI am Circle ";
}

