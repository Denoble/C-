/* Abstract base class. This abstract base class provides only a common interface*/

#ifndef _shape
#define _shape
class Shape {
	public:
		virtual void read() = 0;
		virtual float area()const = 0 ;
virtual void I_am() const = 0;
};
#endif

//No implementation for this abstract class is needed.

