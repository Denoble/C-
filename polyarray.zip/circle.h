/*Definition of Class Circle inherited  from class Point */

#ifndef _circle
#define _cicle
#include "point.h"
class Circle : public Point{
	private:
		float radius;
public:
		virtual void read();
		virtual float area() const;
		virtual void I_am(void) const;
};
#endif
