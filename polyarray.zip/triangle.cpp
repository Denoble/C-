/* The implementation of class Triangle */

#include <iostream>
#include <math.h>
#include "triangle.h"
using namespace std;

void Triangle::read(){
	cout << "\nEnter first apex of triangle";
	P1.read();
	cout << "\nEnter second apex of triangle";
	P2.read();
	cout << "\nEnter first apex of triangle";
	P3.read();
}

float Triangle::area() const {
	float side1, side2, side3, circumference;
	side1 = P1.distance(P2);
	side2 = P2.distance(P3);
	side3 = P3.distance(P1);
	circumference = (side1 + side2 + side3)/2.0f;
	return sqrt(circumference * (circumference - side1) * (circumference - side2) 
		* (circumference - side3));
}

void Triangle::I_am() const {
	cout << "\nI am Triangle ";
}
