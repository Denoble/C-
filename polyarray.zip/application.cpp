/* Application that demonstrates a polymorphic shape array */

#include <iostream>
#include "circle.h"
#include "triangle.h"
using namespace std;

void main (void) {
	Shape *shapeArray[4];
	int i;

	for (i = 0 ; i < 4; i++) {
		if (i%2) {
			shapeArray[i] = new Triangle;
		}
		else {
			shapeArray[i] = new Circle;
		}
		shapeArray[i]->read();

	}

	for (i = 0 ; i < 4; i++) {
		shapeArray[i]->I_am();
		cout << "\nThe area of shape " << i << " is " <<  shapeArray[i]->area();
	}
}
