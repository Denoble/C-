/* Implementation of class Point */

#include <iostream>
#include <math.h>
#include "point.h"
using namespace std;

void Point::read() {
	cout << "\n Enter x-coordinate of point: ";
	cin >> x;
	cout << " Enter y-coordinate of point: ";
	cin >> y;
}

float Point::area() const {
	return 0.0;
}
void Point::I_am() const {
	cout << "\nI am Point ";
}
float Point::distance(const Point &p2)const{
	return sqrt( (p2.x-x)*(p2.x-x) + (p2.y - y)*(p2.y - y));
}
